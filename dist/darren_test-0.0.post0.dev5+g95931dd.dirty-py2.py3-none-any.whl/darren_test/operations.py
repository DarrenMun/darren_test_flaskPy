import sys

class Ops():		
	def get_addition(self,x = 0, y = 0):
		test_add = x + y
		return test_add

	def get_subtraction(self,x = 0,y = 0):
		test_sub = x - y
		return test_sub

	def get_multiplication(self,x = 0,y = 0):
		test_multi = x * y
		return test_multi

	def get_division(self,x = 0, y = 0):
		test_div = x / y
		return test_div

