import sys

def get_addition():
	return 5

def get_subtraction():
	sum = 6-2
	return 4